from django.shortcuts import render, redirect
from django.contrib import messages
from cart.cart import Cart
from .forms import CheckoutForm
from .models import Order, OrderItem
def checkout(request):
    cart = Cart(request)
    if request.method == "POST":
        form = CheckoutForm(request.POST)
        if form.is_valid() and len(cart) > 0:
            order = Order.objects.create(
                user_email=request.user.email if request.user.is_authenticated else "",
                name=form.cleaned_data['name'],
                address=form.cleaned_data['address'],
            )
            for item in cart:
                OrderItem.objects.create(order=order, product_title=item['product'].title, price=item['product'].price, quantity=item['quantity'])
            cart.clear()
            messages.success(request, f"Order #{order.id} placed successfully!")
            return redirect('/')
    else:
        form = CheckoutForm()
    return render(request, "orders/checkout.html", {"form": form, "cart": cart})
