from .cart import Cart
def cart(request): return {'cart_count': len(Cart(request))}
