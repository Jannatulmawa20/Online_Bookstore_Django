from django.shortcuts import render, redirect
from .cart import Cart
from .forms import AddToCartForm
def detail(request):
    cart = Cart(request)
    return render(request, "cart/detail.html", {"cart": cart})
def add(request, product_id):
    cart = Cart(request)
    if request.method == "POST":
        form = AddToCartForm(request.POST)
        if form.is_valid():
            cart.add(product_id=product_id, quantity=form.cleaned_data['quantity'])
    return redirect("cart:detail")
def remove(request, product_id):
    cart = Cart(request)
    cart.remove(product_id)
    return redirect("cart:detail")
