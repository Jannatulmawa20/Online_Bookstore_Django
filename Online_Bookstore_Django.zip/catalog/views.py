from django.core.paginator import Paginator
from django.db.models import Q
from django.shortcuts import render, get_object_or_404
from .models import Product, Category
from cart.forms import AddToCartForm
def product_list(request, slug=None):
    category = None
    categories = Category.objects.all()
    products = Product.objects.filter(is_active=True)
    q = request.GET.get("q")
    if q:
        products = products.filter(Q(title__icontains=q) | Q(description__icontains=q))
    if slug:
        category = get_object_or_404(Category, slug=slug)
        products = products.filter(category=category)
    paginator = Paginator(products, 9)
    page_obj = paginator.get_page(request.GET.get("page"))
    return render(request, "catalog/product_list.html", {"category":category,"categories":categories,"page_obj":page_obj,"q": q or ""})
def product_detail(request, slug):
    product = get_object_or_404(Product, slug=slug, is_active=True)
    form = AddToCartForm()
    return render(request, "catalog/product_detail.html", {"product": product, "form": form})
