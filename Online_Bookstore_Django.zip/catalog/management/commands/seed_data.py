from django.core.management.base import BaseCommand
from django.utils.text import slugify
from catalog.models import Category, Product
from decimal import Decimal
SAMPLES = [
    ("Fiction", [("The Silent Sea","A gripping mystery novel.","499.00"),
                 ("Midnight Library","Between life and death, there is a library.","650.00"),
                 ("River of Stars","An epic tale across ages.","790.00")]),
    ("Programming", [("Django for Beginners","Build websites with Django.","1200.00"),
                     ("Python Tricks","A Buffet of Awesome Python Features.","950.00"),
                     ("Two Scoops of Django","Best practices for Django.","1500.00")]),
    ("Non-fiction", [("Atomic Habits","Build good habits & break bad ones.","990.00"),
                     ("Deep Work","Rules for focused success.","850.00")]),
]
class Command(BaseCommand):
    help = "Seed demo categories and products"
    def handle(self, *args, **kwargs):
        count = 0
        for cat_name, items in SAMPLES:
            cat, _ = Category.objects.get_or_create(name=cat_name, defaults={"slug": slugify(cat_name)})
            for title, desc, price in items:
                Product.objects.get_or_create(
                    title=title,
                    defaults={"category":cat,"slug":slugify(title),"description":desc,"price":Decimal(price),"stock":20,"is_active":True}
                ); count += 1
        self.stdout.write(self.style.SUCCESS(f"Seeded {count} products."))
